package com.example.testapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Objects;

public class second extends AppCompatActivity {
static  int number;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
         number = Objects.requireNonNull(getIntent().getExtras()).getInt("value");
        displayscore(number);
        display_grade(number);
    }
    public void displayscore(int number)
    {
        TextView A =(TextView) findViewById(R.id.textView2);
        A.setText(String.valueOf(number));
    }
    public void display_grade(int number)
    {
        if(number==0)
        {
            TextView textView3 = (TextView) findViewById(R.id.textView3);
            String s= "Try Again";
            textView3.setText(String.valueOf(s));
        }
        else if(number==5 || number==10)
        {
            TextView textView3 = (TextView) findViewById(R.id.textView3);
            String s= "Good Attempt";
            textView3.setText(String.valueOf(s));
        }
        else if(number==20 || number==15)
        {
            TextView textView3 = (TextView) findViewById(R.id.textView3);
            String s= "Average";
            textView3.setText(String.valueOf(s));
        }
        else if(number==25)
        {
            TextView textView3 = (TextView) findViewById(R.id.textView3);
            String s ="Very Good";
            textView3.setText(String.valueOf(s));
        }
        else if(number==30 || number==35)
        {
            TextView textView3 = (TextView) findViewById(R.id.textView3);
            String s= "Perfect";
            textView3.setText(String.valueOf(s));
        }
        else if(number==40 || number==45)
        {
            TextView textView3 = (TextView) findViewById(R.id.textView3);
            String s ="Ecellent";
            textView3.setText(String.valueOf(s));
        }
        else
        {
            TextView textView3 = (TextView) findViewById(R.id.textView3);
            String s = "Yes! you are the winner";
            textView3.setText(String.valueOf(s));
        }
    }

    public void first(View view) {
        number=0;
        Intent i = new Intent(second.this, MainActivity.class);
        i.putExtra("value1",number);
        startActivity(i);
    }
}
