package com.example.testapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
          int score=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Third(View view) {
        Intent i = new Intent(MainActivity.this, second.class);
        i.putExtra("value",score);
        startActivity(i);
    }

    public void v1(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v2(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v3(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v4(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v5(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v6(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v7(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v8(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v9(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void v10(View view) {
        boolean checked = ((RadioButton) view) .isChecked();
        if(checked)
        {
            score= score +5;
        }
    }

    public void clear(View view) {
      RadioButton r1= findViewById(R.id.r1);
        RadioButton r2= findViewById(R.id.r2);
        RadioButton r3= findViewById(R.id.r3);
        RadioButton r4= findViewById(R.id.r4);
        r1.setChecked(false);
        r2.setChecked(false);        r3.setChecked(false);        r4.setChecked(false);
        RadioButton ra= findViewById(R.id.ra);
        RadioButton rb= findViewById(R.id.rb); RadioButton rc= findViewById(R.id.rc); RadioButton rd= findViewById(R.id.rd);
        ra.setChecked(false);
        rb.setChecked(false);        rc.setChecked(false);        rd.setChecked(false);
        RadioButton rb1= findViewById(R.id.rb1); RadioButton rb2= findViewById(R.id.rb2);RadioButton rb3= findViewById(R.id.rb3); RadioButton rb4= findViewById(R.id.rb4);
        rb1.setChecked(false); rb2.setChecked(false);rb3.setChecked(false); rb4.setChecked(false);

        RadioButton rbt1= findViewById(R.id.rbt1); RadioButton rbt2= findViewById(R.id.rbt2);RadioButton rbt3= findViewById(R.id.rbt3); RadioButton rbt4= findViewById(R.id.rbt4);
        rbt1.setChecked(false); rbt2.setChecked(false);rbt3.setChecked(false); rbt4.setChecked(false);

        RadioButton bt1= findViewById(R.id.bt1); RadioButton bt2= findViewById(R.id.bt2);RadioButton bt3= findViewById(R.id.bt3); RadioButton bt4= findViewById(R.id.bt4);
        bt1.setChecked(false); bt2.setChecked(false);bt3.setChecked(false); bt4.setChecked(false);

        RadioButton b1= findViewById(R.id.b1); RadioButton b2= findViewById(R.id.b2);RadioButton b3= findViewById(R.id.b3); RadioButton b4= findViewById(R.id.b4);
        b1.setChecked(false); b2.setChecked(false);b3.setChecked(false); b4.setChecked(false);

        RadioButton btn1= findViewById(R.id.btn1); RadioButton btn2= findViewById(R.id.btn2);RadioButton btn3= findViewById(R.id.btn3); RadioButton btn4= findViewById(R.id.btn4);
        btn1.setChecked(false); btn2.setChecked(false);btn3.setChecked(false); btn4.setChecked(false);

        RadioButton n1= findViewById(R.id.n1); RadioButton n2= findViewById(R.id.n2);RadioButton n3= findViewById(R.id.n3); RadioButton n4= findViewById(R.id.n4);
        n1.setChecked(false); n2.setChecked(false);n3.setChecked(false); n4.setChecked(false);

        RadioButton tn1= findViewById(R.id.tn1); RadioButton tn2= findViewById(R.id.tn2);RadioButton tn3= findViewById(R.id.tn3); RadioButton tn4= findViewById(R.id.tn4);
        tn1.setChecked(false); tn2.setChecked(false);tn3.setChecked(false); tn4.setChecked(false);

        RadioButton B1= findViewById(R.id.B1); RadioButton B2= findViewById(R.id.B2);RadioButton B3= findViewById(R.id.B3); RadioButton B4= findViewById(R.id.B4);
        B1.setChecked(false); B2.setChecked(false);B3.setChecked(false); B4.setChecked(false);
        score=0;
    }
}
